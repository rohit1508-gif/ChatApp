package com.example.chatapp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.chatapp.R;
import com.example.chatapp.ModalClass.User;
import com.example.chatapp.Adapter.UserAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

public class UsernameActivity extends AppCompatActivity {
    private UserAdapter adapter;
    RecyclerView recyclerView;
    private Context ctx;
    DatabaseReference databasenote;
    List<User> muser;
    String uid,name,imageUrl;
    SharedPreferences sp;
    FirebaseUser fuser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        fuser = FirebaseAuth.getInstance().getCurrentUser();
        uid = fuser.getUid();
        sp = getSharedPreferences("login",MODE_PRIVATE);
        databasenote = FirebaseDatabase.getInstance().getReference("Users");
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        muser= new ArrayList<>();
        ctx = UsernameActivity.this;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        databasenote.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    for(DataSnapshot napshot : snapshot.getChildren()){
                        User l =napshot.getValue(User.class);
                        if(!(l.getUid().equals(uid)))
                        muser.add(l);
                    }
                adapter = new UserAdapter(muser,ctx);
                recyclerView.setAdapter(adapter);}
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.logout_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case R.id.subitem1:
                sp.edit().putBoolean("logged",false).apply();
                Intent intent  = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                return true;
            case R.id.Profile:
                Intent i  = new Intent(getApplicationContext(), ProfileActivity.class);
                startActivity(i);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onBackPressed(){
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);
    }
private void status(String status){
    HashMap<String,Object> hashMap = new HashMap<>();
    hashMap.put("status",status);
    FirebaseDatabase.getInstance().getReference("Users").child(uid).updateChildren(hashMap);
}

    @Override
    protected void onResume() {
        super.onResume();
        status("online");
    }

    @Override
    protected void onPause() {
        super.onPause();
        String currentDateTimeString = java.text.DateFormat.getDateTimeInstance().format(new Date());
        status(currentDateTimeString);
    }
}
